const express = require('express');
const cors = require('cors');
const app = express();

const { poolPromise } = require('./db');

const authRoutes = require('./routes/signup');

// Middleware
app.use(cors()); // permite cereri de pe alte porturi (ex: React)
app.use(express.json()); // permite parsarea JSON-ului din request body

// Prefixul API pentru rute
app.use('/api', authRoutes);


// // Ruta de test (opțional)
// app.get('/', (req, res) => {
//   res.send('Backend-ul funcționează! 🐾');
// });

// Pornește serverul
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`✅ Server pornit pe http://localhost:${PORT}`);
});
