import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './frontend/home';
import AccountType from './frontend/auth/accountType';
import ClinicSignUp from './frontend/auth/clinicSignUp';
import OwnerSignUp from './frontend/auth/ownerSignUp';
// import Login from './Login';
// import Welcome from './Welcome'; // Pagina după înregistrare

function App() {
  return (
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/accountType" element={<AccountType />} />
        <Route path="/signupAsClinic" element={<ClinicSignUp />} />
        <Route path="/signupAsOwner" element={<OwnerSignUp />} />
        {/* <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<Welcome />} /> */}
      </Routes>
  );
}

export default App;